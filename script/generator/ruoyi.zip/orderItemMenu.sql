-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483023278082, '订单明细', '3', '1', 'orderItem', 'ecom/orderItem/index', 1, 0, 'C', '0', '0', 'ecom:orderItem:list', '#', 103, 1, now(), null, null, '订单明细菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483023278083, '订单明细查询', 2021486483023278082, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderItem:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483023278084, '订单明细新增', 2021486483023278082, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderItem:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483023278085, '订单明细修改', 2021486483023278082, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderItem:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483023278086, '订单明细删除', 2021486483023278082, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderItem:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483023278087, '订单明细导出', 2021486483023278082, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderItem:export',       '#', 103, 1, now(), null, null, '');

