-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476362723329, '用户地址关联', '3', '1', 'userAddress', 'ecom/userAddress/index', 1, 0, 'C', '0', '0', 'ecom:userAddress:list', '#', 103, 1, now(), null, null, '用户地址关联菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476362723330, '用户地址关联查询', 2021486476362723329, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:userAddress:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476362723331, '用户地址关联新增', 2021486476362723329, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:userAddress:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476362723332, '用户地址关联修改', 2021486476362723329, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:userAddress:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476362723333, '用户地址关联删除', 2021486476362723329, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:userAddress:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476362723334, '用户地址关联导出', 2021486476362723329, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:userAddress:export',       '#', 103, 1, now(), null, null, '');

