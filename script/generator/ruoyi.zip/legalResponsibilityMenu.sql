-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480288591874, '法律责任', '3', '1', 'legalResponsibility', 'ecom/legalResponsibility/index', 1, 0, 'C', '0', '0', 'ecom:legalResponsibility:list', '#', 103, 1, now(), null, null, '法律责任菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480288591875, '法律责任查询', 2021486480288591874, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:legalResponsibility:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480288591876, '法律责任新增', 2021486480288591874, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:legalResponsibility:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480288591877, '法律责任修改', 2021486480288591874, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:legalResponsibility:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480288591878, '法律责任删除', 2021486480288591874, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:legalResponsibility:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480288591879, '法律责任导出', 2021486480288591874, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:legalResponsibility:export',       '#', 103, 1, now(), null, null, '');

