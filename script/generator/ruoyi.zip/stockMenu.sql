-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479869161474, '通用库存', '3', '1', 'stock', 'ecom/stock/index', 1, 0, 'C', '0', '0', 'ecom:stock:list', '#', 103, 1, now(), null, null, '通用库存菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479869161475, '通用库存查询', 2021486479869161474, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stock:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479869161476, '通用库存新增', 2021486479869161474, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stock:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479869161477, '通用库存修改', 2021486479869161474, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stock:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479869161478, '通用库存删除', 2021486479869161474, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stock:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479869161479, '通用库存导出', 2021486479869161474, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stock:export',       '#', 103, 1, now(), null, null, '');

