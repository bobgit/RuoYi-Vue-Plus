-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481693683714, '活动属性', '3', '1', 'activityAttributes', 'ecom/activityAttributes/index', 1, 0, 'C', '0', '0', 'ecom:activityAttributes:list', '#', 103, 1, now(), null, null, '活动属性菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481693683715, '活动属性查询', 2021486481693683714, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activityAttributes:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481693683716, '活动属性新增', 2021486481693683714, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activityAttributes:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481693683717, '活动属性修改', 2021486481693683714, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activityAttributes:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481693683718, '活动属性删除', 2021486481693683714, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activityAttributes:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481693683719, '活动属性导出', 2021486481693683714, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activityAttributes:export',       '#', 103, 1, now(), null, null, '');

