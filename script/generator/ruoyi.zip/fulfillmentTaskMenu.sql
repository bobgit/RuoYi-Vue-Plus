-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482310246402, '履约单', '3', '1', 'fulfillmentTask', 'ecom/fulfillmentTask/index', 1, 0, 'C', '0', '0', 'ecom:fulfillmentTask:list', '#', 103, 1, now(), null, null, '履约单菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482310246403, '履约单查询', 2021486482310246402, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:fulfillmentTask:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482310246404, '履约单新增', 2021486482310246402, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:fulfillmentTask:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482310246405, '履约单修改', 2021486482310246402, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:fulfillmentTask:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482310246406, '履约单删除', 2021486482310246402, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:fulfillmentTask:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482310246407, '履约单导出', 2021486482310246402, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:fulfillmentTask:export',       '#', 103, 1, now(), null, null, '');

