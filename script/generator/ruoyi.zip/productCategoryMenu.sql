-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481832095745, '商品分类', '3', '1', 'productCategory', 'ecom/productCategory/index', 1, 0, 'C', '0', '0', 'ecom:productCategory:list', '#', 103, 1, now(), null, null, '商品分类菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481832095746, '商品分类查询', 2021486481832095745, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productCategory:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481832095747, '商品分类新增', 2021486481832095745, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productCategory:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481832095748, '商品分类修改', 2021486481832095745, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productCategory:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481832095749, '商品分类删除', 2021486481832095745, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productCategory:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481832095750, '商品分类导出', 2021486481832095745, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productCategory:export',       '#', 103, 1, now(), null, null, '');

