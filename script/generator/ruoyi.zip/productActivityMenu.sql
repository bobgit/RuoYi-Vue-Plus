-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483933442050, '活动商品关联', '3', '1', 'productActivity', 'ecom/productActivity/index', 1, 0, 'C', '0', '0', 'ecom:productActivity:list', '#', 103, 1, now(), null, null, '活动商品关联菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483933442051, '活动商品关联查询', 2021486483933442050, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productActivity:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483933442052, '活动商品关联新增', 2021486483933442050, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productActivity:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483933442053, '活动商品关联修改', 2021486483933442050, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productActivity:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483933442054, '活动商品关联删除', 2021486483933442050, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productActivity:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483933442055, '活动商品关联导出', 2021486483933442050, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productActivity:export',       '#', 103, 1, now(), null, null, '');

