-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480573804546, '订单变更动态日志', '3', '1', 'orderLog', 'ecom/orderLog/index', 1, 0, 'C', '0', '0', 'ecom:orderLog:list', '#', 103, 1, now(), null, null, '订单变更动态日志菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480573804547, '订单变更动态日志查询', 2021486480573804546, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderLog:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480573804548, '订单变更动态日志新增', 2021486480573804546, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderLog:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480573804549, '订单变更动态日志修改', 2021486480573804546, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderLog:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480573804550, '订单变更动态日志删除', 2021486480573804546, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderLog:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480573804551, '订单变更动态日志导出', 2021486480573804546, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderLog:export',       '#', 103, 1, now(), null, null, '');

