-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483304296450, '团购参团记录', '3', '1', 'groupRecord', 'ecom/groupRecord/index', 1, 0, 'C', '0', '0', 'ecom:groupRecord:list', '#', 103, 1, now(), null, null, '团购参团记录菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483304296451, '团购参团记录查询', 2021486483304296450, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupRecord:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483304296452, '团购参团记录新增', 2021486483304296450, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupRecord:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483304296453, '团购参团记录修改', 2021486483304296450, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupRecord:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483304296454, '团购参团记录删除', 2021486483304296450, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupRecord:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483304296455, '团购参团记录导出', 2021486483304296450, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupRecord:export',       '#', 103, 1, now(), null, null, '');

