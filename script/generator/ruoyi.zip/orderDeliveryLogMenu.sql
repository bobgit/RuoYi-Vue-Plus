-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483723726849, '配送状态变更日志', '3', '1', 'orderDeliveryLog', 'ecom/orderDeliveryLog/index', 1, 0, 'C', '0', '0', 'ecom:orderDeliveryLog:list', '#', 103, 1, now(), null, null, '配送状态变更日志菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483723726850, '配送状态变更日志查询', 2021486483723726849, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDeliveryLog:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483723726851, '配送状态变更日志新增', 2021486483723726849, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDeliveryLog:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483723726852, '配送状态变更日志修改', 2021486483723726849, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDeliveryLog:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483723726853, '配送状态变更日志删除', 2021486483723726849, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDeliveryLog:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483723726854, '配送状态变更日志导出', 2021486483723726849, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDeliveryLog:export',       '#', 103, 1, now(), null, null, '');

