-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486477566488577, '库存流水', '3', '1', 'stockFlow', 'ecom/stockFlow/index', 1, 0, 'C', '0', '0', 'ecom:stockFlow:list', '#', 103, 1, now(), null, null, '库存流水菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486477566488578, '库存流水查询', 2021486477566488577, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stockFlow:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486477566488579, '库存流水新增', 2021486477566488577, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stockFlow:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486477566488580, '库存流水修改', 2021486477566488577, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stockFlow:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486477566488581, '库存流水删除', 2021486477566488577, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stockFlow:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486477566488582, '库存流水导出', 2021486477566488577, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:stockFlow:export',       '#', 103, 1, now(), null, null, '');

