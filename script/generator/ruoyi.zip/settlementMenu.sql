-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478124331009, '结算', '3', '1', 'settlement', 'ecom/settlement/index', 1, 0, 'C', '0', '0', 'ecom:settlement:list', '#', 103, 1, now(), null, null, '结算菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478124331010, '结算查询', 2021486478124331009, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:settlement:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478124331011, '结算新增', 2021486478124331009, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:settlement:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478124331012, '结算修改', 2021486478124331009, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:settlement:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478124331013, '结算删除', 2021486478124331009, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:settlement:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478124331014, '结算导出', 2021486478124331009, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:settlement:export',       '#', 103, 1, now(), null, null, '');

