-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480850628609, 'SKU库存单元', '3', '1', 'productSku', 'ecom/productSku/index', 1, 0, 'C', '0', '0', 'ecom:productSku:list', '#', 103, 1, now(), null, null, 'SKU库存单元菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480850628610, 'SKU库存单元查询', 2021486480850628609, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSku:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480850628611, 'SKU库存单元新增', 2021486480850628609, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSku:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480850628612, 'SKU库存单元修改', 2021486480850628609, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSku:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480850628613, 'SKU库存单元删除', 2021486480850628609, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSku:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486480850628614, 'SKU库存单元导出', 2021486480850628609, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSku:export',       '#', 103, 1, now(), null, null, '');

