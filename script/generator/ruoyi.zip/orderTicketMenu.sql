-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484143157250, '门票/服务专用', '3', '1', 'orderTicket', 'ecom/orderTicket/index', 1, 0, 'C', '0', '0', 'ecom:orderTicket:list', '#', 103, 1, now(), null, null, '门票/服务专用菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484143157251, '门票/服务专用查询', 2021486484143157250, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderTicket:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484143157252, '门票/服务专用新增', 2021486484143157250, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderTicket:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484143157253, '门票/服务专用修改', 2021486484143157250, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderTicket:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484143157254, '门票/服务专用删除', 2021486484143157250, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderTicket:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484143157255, '门票/服务专用导出', 2021486484143157250, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderTicket:export',       '#', 103, 1, now(), null, null, '');

