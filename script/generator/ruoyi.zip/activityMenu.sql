-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483442708482, '活动', '3', '1', 'activity', 'ecom/activity/index', 1, 0, 'C', '0', '0', 'ecom:activity:list', '#', 103, 1, now(), null, null, '活动菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483442708483, '活动查询', 2021486483442708482, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activity:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483442708484, '活动新增', 2021486483442708482, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activity:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483442708485, '活动修改', 2021486483442708482, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activity:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483442708486, '活动删除', 2021486483442708482, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activity:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486483442708487, '活动导出', 2021486483442708482, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:activity:export',       '#', 103, 1, now(), null, null, '');

