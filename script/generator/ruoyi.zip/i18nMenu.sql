-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478539567106, '商品分类', '3', '1', 'i18n', 'ecom/i18n/index', 1, 0, 'C', '0', '0', 'ecom:i18n:list', '#', 103, 1, now(), null, null, '商品分类菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478539567107, '商品分类查询', 2021486478539567106, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:i18n:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478539567108, '商品分类新增', 2021486478539567106, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:i18n:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478539567109, '商品分类修改', 2021486478539567106, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:i18n:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478539567110, '商品分类删除', 2021486478539567106, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:i18n:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478539567111, '商品分类导出', 2021486478539567106, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:i18n:export',       '#', 103, 1, now(), null, null, '');

