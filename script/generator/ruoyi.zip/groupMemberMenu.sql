-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482813562881, '拼团团员', '3', '1', 'groupMember', 'ecom/groupMember/index', 1, 0, 'C', '0', '0', 'ecom:groupMember:list', '#', 103, 1, now(), null, null, '拼团团员菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482813562882, '拼团团员查询', 2021486482813562881, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupMember:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482813562883, '拼团团员新增', 2021486482813562881, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupMember:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482813562884, '拼团团员修改', 2021486482813562881, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupMember:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482813562885, '拼团团员删除', 2021486482813562881, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupMember:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482813562886, '拼团团员导出', 2021486482813562881, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:groupMember:export',       '#', 103, 1, now(), null, null, '');

