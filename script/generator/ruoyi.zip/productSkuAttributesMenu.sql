-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481483968513, '商品SKU属性', '3', '1', 'productSkuAttributes', 'ecom/productSkuAttributes/index', 1, 0, 'C', '0', '0', 'ecom:productSkuAttributes:list', '#', 103, 1, now(), null, null, '商品SKU属性菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481483968514, '商品SKU属性查询', 2021486481483968513, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSkuAttributes:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481483968515, '商品SKU属性新增', 2021486481483968513, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSkuAttributes:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481483968516, '商品SKU属性修改', 2021486481483968513, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSkuAttributes:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481483968517, '商品SKU属性删除', 2021486481483968513, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSkuAttributes:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481483968518, '商品SKU属性导出', 2021486481483968513, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSkuAttributes:export',       '#', 103, 1, now(), null, null, '');

