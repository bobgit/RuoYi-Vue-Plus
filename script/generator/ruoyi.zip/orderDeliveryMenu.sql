-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479516839937, '订单配送专用', '3', '1', 'orderDelivery', 'ecom/orderDelivery/index', 1, 0, 'C', '0', '0', 'ecom:orderDelivery:list', '#', 103, 1, now(), null, null, '订单配送专用菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479516839938, '订单配送专用查询', 2021486479516839937, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDelivery:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479516839939, '订单配送专用新增', 2021486479516839937, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDelivery:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479516839940, '订单配送专用修改', 2021486479516839937, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDelivery:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479516839941, '订单配送专用删除', 2021486479516839937, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDelivery:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486479516839942, '订单配送专用导出', 2021486479516839937, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:orderDelivery:export',       '#', 103, 1, now(), null, null, '');

