-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484352872450, '国际地址', '3', '1', 'addresses', 'system/addresses/index', 1, 0, 'C', '0', '0', 'system:addresses:list', '#', 103, 1, now(), null, null, '国际地址菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484352872451, '国际地址查询', 2021486484352872450, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:addresses:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484352872452, '国际地址新增', 2021486484352872450, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:addresses:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484352872453, '国际地址修改', 2021486484352872450, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:addresses:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484352872454, '国际地址删除', 2021486484352872450, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:addresses:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486484352872455, '国际地址导出', 2021486484352872450, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:addresses:export',       '#', 103, 1, now(), null, null, '');

