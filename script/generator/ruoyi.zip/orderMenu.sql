-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478824779777, '订单', '3', '1', 'order', 'ecom/order/index', 1, 0, 'C', '0', '0', 'ecom:order:list', '#', 103, 1, now(), null, null, '订单菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478824779778, '订单查询', 2021486478824779777, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:order:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478824779779, '订单新增', 2021486478824779777, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:order:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478824779780, '订单修改', 2021486478824779777, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:order:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478824779781, '订单删除', 2021486478824779777, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:order:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486478824779782, '订单导出', 2021486478824779777, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:order:export',       '#', 103, 1, now(), null, null, '');

