-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486474487869441, '机构组织公司', '3', '1', 'org', 'system/org/index', 1, 0, 'C', '0', '0', 'system:org:list', '#', 103, 1, now(), null, null, '机构组织公司菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486474487869442, '机构组织公司查询', 2021486474487869441, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:org:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486474487869443, '机构组织公司新增', 2021486474487869441, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:org:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486474487869444, '机构组织公司修改', 2021486474487869441, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:org:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486474487869445, '机构组织公司删除', 2021486474487869441, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:org:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486474487869446, '机构组织公司导出', 2021486474487869441, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:org:export',       '#', 103, 1, now(), null, null, '');

