-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476866039810, '退款', '3', '1', 'refund', 'ecom/refund/index', 1, 0, 'C', '0', '0', 'ecom:refund:list', '#', 103, 1, now(), null, null, '退款菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476866039811, '退款查询', 2021486476866039810, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:refund:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476866039812, '退款新增', 2021486476866039810, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:refund:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476866039813, '退款修改', 2021486476866039810, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:refund:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476866039814, '退款删除', 2021486476866039810, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:refund:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486476866039815, '退款导出', 2021486476866039810, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:refund:export',       '#', 103, 1, now(), null, null, '');

