-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481135841282, 'SPU标准产品单元', '3', '1', 'productSpu', 'ecom/productSpu/index', 1, 0, 'C', '0', '0', 'ecom:productSpu:list', '#', 103, 1, now(), null, null, 'SPU标准产品单元菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481135841283, 'SPU标准产品单元查询', 2021486481135841282, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSpu:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481135841284, 'SPU标准产品单元新增', 2021486481135841282, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSpu:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481135841285, 'SPU标准产品单元修改', 2021486481135841282, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSpu:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481135841286, 'SPU标准产品单元删除', 2021486481135841282, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSpu:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486481135841287, 'SPU标准产品单元导出', 2021486481135841282, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productSpu:export',       '#', 103, 1, now(), null, null, '');

