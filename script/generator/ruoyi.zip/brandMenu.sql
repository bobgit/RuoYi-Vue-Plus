-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482612236290, '商品品牌', '3', '1', 'brand', 'ecom/brand/index', 1, 0, 'C', '0', '0', 'ecom:brand:list', '#', 103, 1, now(), null, null, '商品品牌菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482612236291, '商品品牌查询', 2021486482612236290, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:brand:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482612236292, '商品品牌新增', 2021486482612236290, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:brand:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482612236293, '商品品牌修改', 2021486482612236290, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:brand:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482612236294, '商品品牌删除', 2021486482612236290, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:brand:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482612236295, '商品品牌导出', 2021486482612236290, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:brand:export',       '#', 103, 1, now(), null, null, '');

