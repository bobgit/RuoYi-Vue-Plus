-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486475809075202, '物流跟踪记录', '3', '1', 'logisticsHistory', 'ecom/logisticsHistory/index', 1, 0, 'C', '0', '0', 'ecom:logisticsHistory:list', '#', 103, 1, now(), null, null, '物流跟踪记录菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486475809075203, '物流跟踪记录查询', 2021486475809075202, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:logisticsHistory:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486475809075204, '物流跟踪记录新增', 2021486475809075202, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:logisticsHistory:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486475809075205, '物流跟踪记录修改', 2021486475809075202, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:logisticsHistory:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486475809075206, '物流跟踪记录删除', 2021486475809075202, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:logisticsHistory:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486475809075207, '物流跟踪记录导出', 2021486475809075202, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:logisticsHistory:export',       '#', 103, 1, now(), null, null, '');

