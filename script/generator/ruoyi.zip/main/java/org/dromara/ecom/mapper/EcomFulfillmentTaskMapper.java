package org.dromara.ecom.mapper;

import org.dromara.ecom.domain.EcomFulfillmentTask;
import org.dromara.ecom.domain.vo.EcomFulfillmentTaskVo;
import org.dromara.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 履约单Mapper接口
 *
 * @author Bob Bai
 * @date 2026-02-11
 */
public interface EcomFulfillmentTaskMapper extends BaseMapperPlus<EcomFulfillmentTask, EcomFulfillmentTaskVo> {

}
