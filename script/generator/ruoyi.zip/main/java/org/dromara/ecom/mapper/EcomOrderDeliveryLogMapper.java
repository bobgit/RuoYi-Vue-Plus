package org.dromara.ecom.mapper;

import org.dromara.ecom.domain.EcomOrderDeliveryLog;
import org.dromara.ecom.domain.vo.EcomOrderDeliveryLogVo;
import org.dromara.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 配送状态变更日志Mapper接口
 *
 * @author Bob Bai
 * @date 2026-02-11
 */
public interface EcomOrderDeliveryLogMapper extends BaseMapperPlus<EcomOrderDeliveryLog, EcomOrderDeliveryLogVo> {

}
