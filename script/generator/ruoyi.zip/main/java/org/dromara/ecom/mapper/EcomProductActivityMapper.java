package org.dromara.ecom.mapper;

import org.dromara.ecom.domain.EcomProductActivity;
import org.dromara.ecom.domain.vo.EcomProductActivityVo;
import org.dromara.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 活动商品关联Mapper接口
 *
 * @author Bob Bai
 * @date 2026-02-11
 */
public interface EcomProductActivityMapper extends BaseMapperPlus<EcomProductActivity, EcomProductActivityVo> {

}
