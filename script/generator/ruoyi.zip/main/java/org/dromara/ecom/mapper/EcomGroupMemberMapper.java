package org.dromara.ecom.mapper;

import org.dromara.ecom.domain.EcomGroupMember;
import org.dromara.ecom.domain.vo.EcomGroupMemberVo;
import org.dromara.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 拼团团员Mapper接口
 *
 * @author Bob Bai
 * @date 2026-02-11
 */
public interface EcomGroupMemberMapper extends BaseMapperPlus<EcomGroupMember, EcomGroupMemberVo> {

}
