package org.dromara.ecom.mapper;

import org.dromara.ecom.domain.EcomGroupRecord;
import org.dromara.ecom.domain.vo.EcomGroupRecordVo;
import org.dromara.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 团购参团记录Mapper接口
 *
 * @author Bob Bai
 * @date 2026-02-11
 */
public interface EcomGroupRecordMapper extends BaseMapperPlus<EcomGroupRecord, EcomGroupRecordVo> {

}
