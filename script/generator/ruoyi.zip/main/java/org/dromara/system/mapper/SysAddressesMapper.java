package org.dromara.system.mapper;

import org.dromara.system.domain.SysAddresses;
import org.dromara.system.domain.vo.SysAddressesVo;
import org.dromara.common.mybatis.core.mapper.BaseMapperPlus;

/**
 * 国际地址Mapper接口
 *
 * @author Lion Li
 * @date 2026-02-11
 */
public interface SysAddressesMapper extends BaseMapperPlus<SysAddresses, SysAddressesVo> {

}
