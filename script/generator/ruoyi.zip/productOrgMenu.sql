-- 菜单 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482113114114, '机构组织商品', '3', '1', 'productOrg', 'ecom/productOrg/index', 1, 0, 'C', '0', '0', 'ecom:productOrg:list', '#', 103, 1, now(), null, null, '机构组织商品菜单');

-- 按钮 SQL
insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482113114115, '机构组织商品查询', 2021486482113114114, '1',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productOrg:query',        '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482113114116, '机构组织商品新增', 2021486482113114114, '2',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productOrg:add',          '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482113114117, '机构组织商品修改', 2021486482113114114, '3',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productOrg:edit',         '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482113114118, '机构组织商品删除', 2021486482113114114, '4',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productOrg:remove',       '#', 103, 1, now(), null, null, '');

insert into sys_menu (menu_id, menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_dept, create_by, create_time, update_by, update_time, remark)
values(2021486482113114119, '机构组织商品导出', 2021486482113114114, '5',  '#', '', 1, 0, 'F', '0', '0', 'ecom:productOrg:export',       '#', 103, 1, now(), null, null, '');

